<?php require_once('header.php'); ?>
<div class="container">
    <?php require_once('nav.php'); ?>
    <div class="row">
        <div class="mb-3 col-md-6 col-sm-12">
            <img class="mw-100" src="../pictures/beekepers.jpg">
        </div>
        <p class="col-md-6 col-sm-12 mt-5">
            Odwiedź blog pszczelarski założony przez Marcina i Kamila, 
            dzięki któremu zapoznasz się z ciekawostkami na temat pszczół, 
            ich życia i nawyków, hodowli, zakładania oraz prowadzenia pasiek, 
            opieki nad rodzinami pszczół, a także dotyczących produktów pszczelich, 
            które mogą mieć bardzo szerokie zastosowanie nie tylko kulinarne, 
            ale także kosmetyczne czy nawet farmaceutyczne.<br><br>
            Na naszym blogu czeka na Ciebie całe mnóstwo ciekawostek dotyczących pszczół 
            i produktów pszczelich, a także rady niezbędne dla tych, którzy myślą o 
            założeniu swojej własnej pasieki. Tu poznasz także historię Pszczelego Azylu, 
            który powstał w wyniku prawdziwej pasji pszczelarskiej.<br><br>
            <b>Zachęcamy do lektury!</b>
        </p>
    </div>
</div>
<?php require_once('footer.php'); ?>