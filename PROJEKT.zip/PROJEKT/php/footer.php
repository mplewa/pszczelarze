        <div class="fixed-bottom py-3 footer text-muted text-center text-small">
            © M.I.O.D S.A. Marcin Plewa & Kamil Tuszyński
        </div>
    </body>
</html>