<?php require_once('header.php'); ?>
<div class="home-icon"><a href="index.php"><i class="fa-solid fa-house fa-2xl text-left pt-3 ps-3"></i></a></div>
<div class="container">
    <div class="row">
        <div class="col-md-3 col-sm-12">
            <img class="avatar mb-2" src="../pictures/avatar.jpg" alt="avatar">
            <h1>Witaj<br><?php echo $_SESSION['username']?></h1>
            <?php
                $userdataQuery = "SELECT `creation_date` FROM `users` WHERE `username` LIKE '".$_SESSION['username']."';";
                $userdataResult = mysqli_query($connect, $userdataQuery);
                while($t = $userdataResult -> fetch_assoc()){
                    $creationDate = substr($t['creation_date'], 0, 10);
                    echo "Data utworzenia konta: $creationDate";
                }
            ?>
        </div>
        <?php
            if (!isset($_SESSION['loggedIn'])){ // Funkcja login token, zalogowany przyjmuje wartość 1, niezalogowany - 0.
                $loginToken = 0;
            } else {
                $loginToken = $_SESSION['loggedIn'];
            }
            if($loginToken == 1 || isset($loginToken)){
                if($_SESSION['role'] == 1){
                    echo "<form class='text-center postForm col-md-9 col-sm-12' method='post' action='upload.php' enctype='multipart/form-data'>";
                    echo "<h2>Add a post:</h2>";
                    echo "<input type='text' size='45' name='postTitle' id='postTitle' placeholder='Post Title'><br><br>";
                    echo "<textarea rows='10' cols='48' name='postDesc' id='postDesc' placeholder='Post Description'></textarea><br><br>";
                    echo "<input type='file' name='postImg'><br><br>";
                    echo "<input class='upload' type='submit' name='submit' id='submit' value='UPLOAD POST'>";
                    echo "<input type='reset' name='reset' id='reset' value='RESET'>";
                    echo "</form>";
                } else {
                    echo "<div class='yt col-md-9 col-sm-12'>";
                    echo "<iframe width='800' height='450' src='https://www.youtube.com/embed/Wkk5xn5db7E' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>";
                    echo "</div>";
                }
            }
        ?>
    </div>
</div>
<?php require_once('footer.php'); ?>