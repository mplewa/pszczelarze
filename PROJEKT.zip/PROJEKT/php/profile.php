<?php require_once('header.php'); ?>
<div class="home-icon"><a href="index.php"><i class="fa-solid fa-house fa-2xl text-left pt-3 ps-3"></i></a></div>
<div class="container">
    <div class="justify-content-md-center">
        <img class="avatar mb-2" src="../pictures/avatar.jpg" alt="avatar">
        <h1>Witaj<br><?php echo $_SESSION['username'] ?></h1>
    </div>
    <?php
        if (!isset($_SESSION['loggedIn'])){ // Funkcja login token, zalogowany przyjmuje wartość 1, niezalogowany - 0.
            $loginToken = 0;
        } else {
            $loginToken = $_SESSION['loggedIn'];
        }

        if($loginToken == 1 || isset($loginToken)){
            $userdataQuery = "SELECT `date` FROM `users` WHERE `username` LIKE '".$_SESSION['username']."';";
            while($t = mysqli_query($connect, $userdataQuery)){
                echo "Data utworzenia konta: ".$t['date'];
            }
            echo "<form class='text-center postForm' method='post' action='upload.php' enctype='multipart/form-data'>";
            echo "<h2>Add a post:</h2>";
            echo "<input type='text' size='45' name='postTitle' id='postTitle' placeholder='Post Title'><br><br>";
            echo "<textarea rows='10' cols='48' name='postDesc' id='postDesc' placeholder='Post Description'></textarea><br><br>";
            echo "<input type='file' name='postImg'><br><br>";
            echo "<input class='upload' type='submit' name='submit' id='submit' value='UPLOAD IMAGE'>";
            echo "<input type='reset' name='reset' id='reset' value='RESET'>";
            echo "</form>";
        }
    ?>
</div>
<?php require_once('footer.php'); ?>