<?php require_once('header.php'); ?>
<div class="container">
    <?php require_once('nav.php'); ?>
    <div class="contact row text-center">
        <h3 class="mb-5">© M.I.O.D S.A. Marcin Plewa & Kamil Tuszyński</h3>
        <div>
            <b>Dyrektor ds. konserwacji miodu</b>
            <hr class="w-50">
            Marcin Plewa
            <hr class="w-50">
            <a href="tel:+48765432100">+48 765 432 100</a><br>
            <a href="mailto:plewamarcin@miod.pl">plewamarcin@miod.pl</a>
        </div>
        <hr class="hidden-line w-50">
        <div>
            <b>Dyrektor ds. sprawdzania jakości</b>
            <hr class="w-50">
            Kamil Tuszyński
            <hr class="w-50">
            <a href="tel:+48765432105">+48 765 432 105</a><br>
            <a href="mailto:tuszynskikamil@miod.pl">tuszynskikamil@miod.pl</a>
        </div>

    </div>
</div>
<?php require_once('footer.php'); ?>