<?php require_once('header.php'); ?>
<?php
    if(isset($_POST['postTitle']) && isset($_POST['postDesc']) && isset($_FILES['postImg'])){
        $postTitle = $_POST['postTitle'];
        $postDesc = $_POST['postDesc'];
        $postImg = $_FILES['postImg'];

        $fileName = $postImg['name'];
        $fileError = $postImg['error'];
        $fileTmp = $postImg['tmp_name'];

        $fileExt = explode('.', $fileName);
        $fileCheck = strtolower(end($fileExt));
        $fileExtStored = array('png', 'jpg', 'jpeg');

        if(in_array($fileCheck, $fileExtStored)){
            $fileDestination = $fileName;
            move_uploaded_file($fileTmp, $fileDestination);
            header("location: index.php");

            $insertQuery = "INSERT INTO `posts`(`id`, `title`, `desc`, `img_src`, `date`) VALUES (NULL,'$postTitle','$postDesc','$fileDestination', DEFAULT)";
            
            $uploadResult = mysqli_query($connect, $insertQuery);
        } else {
            echo "Invalid extension.";
            header("Refresh: 2, URL=profile.php");
        }
    }
?>