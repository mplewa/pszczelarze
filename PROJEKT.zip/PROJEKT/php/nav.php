<div class="text-center">
        <a href="index.php"><img class="logo" src="../pictures/logotype.png" alt="logo"></a>
</div>
<div>
    <ul class="list-group d-flex list-group-horizontal pb-5">
        <li class="list-group-item"><a href="about.php">About us</a></li>
        <li class="list-group-item"><a href="contact.php">Contact</a></li>
        <?php 
        if (!isset($_SESSION['loggedIn'])){ //Funkcja login token, zalogowany przyjmuje wartość 1, niezalogowany - 0.
            $loginToken = 0;
        } else {
            $loginToken = $_SESSION['loggedIn'];
        }

        if ($loginToken == 0 || !isset($loginToken)){
        echo '<li class="list-group-item"><a href="login.php">Sign in</a></li>';
        } else {
        echo '<li class="list-group-item"><a href="profile.php">Profile</a></li>';
        echo '<li class="list-group-item"><a href="logout.php">Sign out</a></li>';
        }
        ?>
    </ul>
</div>