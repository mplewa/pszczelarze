<?php require_once('header.php'); ?>
<div class="container">
    <?php require_once('nav.php'); ?>
    <div class="row">
        <?php
            $postsQuery = "SELECT * FROM `posts`";
            $queryResult = mysqli_query($connect, $postsQuery);
            while($t = mysqli_fetch_assoc($queryResult)){
                $imgSrc = $t['img_src'];
                $date = substr($t['date'], 0, 10);
                $desc = substr($t['desc'], 0, 200);
                echo "<div class='col-md-6 col-sm-12 mb-3'>";
                echo "<div class='postImage mb-2'>";
                echo "<img src=".$imgSrc.">";
                echo "</div>";
                echo "<h4>".$t['title']."</h4>";
                echo "<h6>$date</h6>";
                echo "<p class='text-justify'>".$desc."...</p>";
                echo "<a href='#'>Read more</a>";
                echo "</div>";
            }
        ?>
    </div>
</div>
<?php require_once('footer.php'); ?>
