Wszystkie treści oraz elementy graficzne umieszczone w tym serwisie nie są naszą własnością!

Zdjęcia zostały wybrane z wyszukiwarki Google po wpisaniu odpowiednich fraz. Natomiast treści ze stron wypisanych poniżej:
- http://www.pszczeliazyl.pl/blog/

Numery telefonów oraz adresy email występujące na stronie są losowe i nie istnieją, bądź do nas nie należą.

Marcin Plewa & Kamil Tuszyński